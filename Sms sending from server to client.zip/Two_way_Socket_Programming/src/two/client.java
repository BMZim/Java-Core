
package two;


import java.io.*;
import java.net.*;

public class client {
    public static void main(String[] args) {
        int port = 5000; 

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);
            Socket socket = serverSocket.accept(); 
            System.out.println("Server Connected");

            
            try (BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter output = new PrintWriter(socket.getOutputStream(), true)) {

                String message;
                while ((message = input.readLine()) != null) {
                    System.out.println("Received from Server: " + message);
                    output.println("Echo: " + message);
                }
            } catch (IOException e) {
                System.out.println("Error in communication: " + e.getMessage());
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
